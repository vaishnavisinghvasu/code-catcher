Place the following fonts in this directory:
- Roboto-Regular.ttf
- Roboto-Bold.ttf
- RobotoMono-Regular.ttf

These fonts can be downloaded from Google Fonts.
